
echo "Enter the range m and n, m<n:"
read m n
echo The given range is from $m to $n
echo The Prime numbers are:
while [ $m -le $n ]
       do 
       i=2; flag=1;
       while [ $i -lt $m ]
               do 
               if [ `expr $m % $i` -eq 0 ]
                       then
                       flag=0
                       break
               else 
                       i=`expr $i + 1`   
               fi
        done
        if [ $flag -eq 1 ]
             then
             echo $m
        fi
        m=`expr $m + 1`
done

echo "Enter Size(N)"
read N

sum=0

echo "Enter Numbers"
for((i=1;i<=N;i++))
do
  read num           #get number
  sum=$((sum + num)) #sum+=num
done

echo $sum   

