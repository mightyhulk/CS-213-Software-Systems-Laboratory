/*Declare an array of length 7 */

$ cat arraymanip.sh

#! /bin/bash
Unix[0]='Kali linux'
Unix[1]='Red hat'
Unix[2]='Ubuntu'
Unix[3]='Suse'
Unix[4]='Linux Mint'
Unix[5]='fedora'
Unix[6]='archlinux'




/* Total Number of Elements */


$ cat arraymanip.sh
declare -a Unix=('Debian' 'Red hat' 'Suse' 'Fedora' 'Linux Mint' 'Linux Mint' archlinux');
echo ${#Unix[@]}
$./arraymanip.sh