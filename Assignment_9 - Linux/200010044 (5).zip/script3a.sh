
cd Desktop
gedit data.txt
sort -k 2 -t "|" data.txt
$ grep -w "Y" file
awk -v RS="[ .,?!]|\n" 'length($0)==5 {a++} END {print Y}' data.txt