
echo ${Unix[@]}

# Add the above echo statement into the arraymanip.sh
#./t.sh