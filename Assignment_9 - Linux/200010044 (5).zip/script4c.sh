/* Print 5th Element */

echo ${Unix[4]}