/* Extract three elements starting from index two */
 

echo ${Unix[2]}
echo ${Unix[3]}
echo ${Unix[4]}

