/* Cut the usernames from the file /etc/passwd */

cat /etc/passwd
cut -f 1 -d: /etc/passwd | tr ":" " " | sort -k 1 |sort -k 2