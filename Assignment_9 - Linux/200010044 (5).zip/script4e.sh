
$cat arraymanip.sh
#!/bin/bash
Unix=('Kali linux' 'Red hat' 'Ubuntu' 'Suse' 'Linux Mint' 'fedora' 'archlinux');

echo ${Unix[@]/Ubuntu/Debian}

$./arraymanip.sh