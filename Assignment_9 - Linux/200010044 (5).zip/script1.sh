cat /etc/passwd


sort -n -t: -k3 /etc/passwd