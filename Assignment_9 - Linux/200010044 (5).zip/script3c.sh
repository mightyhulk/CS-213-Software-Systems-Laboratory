
cd Desktop
gedit data.txt
sed 's/Ankit/Ashish/' data.txt
