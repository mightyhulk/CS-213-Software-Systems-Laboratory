#!/bin/bash
function copyFiles() {
   arr=("$@")
   for i in "${arr[@]}";
      do
          echo "$i"
      done

}

array=("1" "2" "3")

copyFiles "${array[@]}"




/*Second Function */
function Files() {
   arr=("$@")
   for i in "${arr[@]}";
      do
          echo "$i"
      done

}

array=("4" "5" "6")

Files "${array[@]}"