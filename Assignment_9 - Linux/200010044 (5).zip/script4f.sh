
$cat arraymanip.sh
Unix=('Kali linux' 'Red hat' 'Ubuntu' 'Suse' 'Linux Mint' 'fedora' 'archlinux');
Unix=("${Unix[@]}" "AIX")
echo ${Unix[7]}

$./arraymanip.sh