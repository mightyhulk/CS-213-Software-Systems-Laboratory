
cd Desktop
gedit data.txt
sed -n '6~1p' data.txt
sed '13d' data.txt

