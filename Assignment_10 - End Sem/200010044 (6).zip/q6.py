import matplotlib.pyplot as plt
states = 'Andhra Pradesh', 'Assam', 'Bihar', 'Chattisgarh', 'Delhi', 'Gujrat', 'Haryana', 'Himachal Pradesh', 'Jammu & Kashmir','Jharkhand', 'karanataka', 'Kerla','Madhya Pradesh', 'Maharastra', 'Manipur', 'Mizoram' , 'Nagaland', 'Tripura', 'Arunachal Pradesh', 'Meghalaya', 'Oddisha','Punjab' , 'Rajasthan' , 'Tamil Nadu','Telangan', 'Uttaar Pradesh', 'West Bengal', 'Sikkim','Andaman & Nicho bar'
perc=[6.7,2.5,5.8,2.2,0.3,5.7,1.7,1,2.1,6.2,3.2,5.3,8.3,0.4,0.4,0.04,0.2,0.4,0.3,5.2,2.4,6.6,7.6,3.7,11.3,1.7,5.6,0.1,0.06]
explode=(0.1,0,0,0,0,0,0,0,0.1,0,0.2,0.2,0,0,0,0,0,0,0.5,0,0.1,0,0,0.4,0,0,0.3,0,0,0.2)
plt.pie(perc,explode=explode,labels=states,autopct='%1.2f%%',shadow=True)
plt.axis('equal')
plt.show()

# State having max pin
print("Uttar Pradesh")


