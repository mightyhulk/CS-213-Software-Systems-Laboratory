<?php 

error_reporting(0);



 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>

    <form action="" method="POST" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="uploadfile" >
  <br>
  Upload file:
  <input type="submit" value="Upload" name="submit">
</form>
    

 
 </body>
 </html>




<?php




//$filename = $_FILES["uploadfile"] ["name"];
//$filename = $_FILES["uploadfile"] ["tmp_name"];

$filename = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];
$folder = "student/".$filename;
move_uploaded_file($tempname,$folder);
echo $folder;

//$_FILES["uploadfile"];
//move_uploaded_file($tmp_name, $folder);
//echo $folder;






?>


