<?php 

error_reporting(0);
include("connection.php");


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>

    <form action="" method="POST" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="uploadfile" >
  <br>
  Upload file:
  <input type="submit" value="Upload" name="submit">
</form>
    

 </body>
 </html>




<?php


if($_POST['submit']){


$filename = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];
$folder = "gallery/".$filename;
move_uploaded_file($tempname,$folder);

if($filename!="")
{

	$query = "INSERT INTO GALLERY VALUES('$folder')";
	$data = mysqli_query($conn,$query);

 
 if($data)
 {
 	echo "inserted";
 }
 } 

  else 
  {
  	echo "failed";
  }
	
}


?>
