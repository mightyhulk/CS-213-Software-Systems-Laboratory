<?php

$dbhost = "localhost";
$dbusername = "root";
$dbpass = "";
$dbname = "publications";


$conn = mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);
if($conn){

	  echo "ok";
}

else{

	echo  "connection failed".mysqli_connect_error();
}



?>