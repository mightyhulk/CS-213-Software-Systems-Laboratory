<?php



   include("dba.php");
  if(isset($_POST['submit']))  
  {

    $authors=$_POST['authors'];
    $public=$_POST['public'];



    $result=mysqli_query($conn,"INSERT into authors values('$authors','$public')");


if($result){

      header("location:ins1.php");
}

else
{
    echo "not executed";
}



}






?>


<html>
<head>
  <meta charset="utf-8">
  <title>Publication</title>


<style>
#button{

   height: 45px;
   width: 70px;

}



</style>



</head>
<body background="C:\xampp\htdocs\docu\hlt.jpg"; style="background-repeat:no-repeat ; background-size: 100%; font-size: 36px;">

<br>

<form>
   <table align="center">
       <caption>Authors</caption>
   <br>
   
    <tr>

    <td> Author <td> <input type="text" name="author" required> 
    </td>
    </tr>

    <tr>
     <td> Publisher <td> <input type="text" name="publisher" required> 
    </td>
    </tr>

   <tr>
   <td>
   <a href ="lit.html"><input type="submit" id="button" name="submit"></a>
 </td>
   </tr>
  

 </table>
</form>



 <br>

<form>
   <table align="center" title="Titles">
     <caption>Titles</caption>

   <br> 
  
     <tr>
     <td> Title <td> <input type="text"  name="title" required> 
    </td>
    </tr>
     <tr>
     <td> Author <td> <input type="text"  name="authorss" required> 
    </td>
    </tr>

     <tr>
     <td> Year <td> <input type="text"  name="year" required> 
    </td>
    </tr>

<tr><td></td></tr>



   <tr>
   <td>
  <a href="https://www.nasa.gov/"><input type="submit" id="button" name="submits"></a>
   </td>
   </tr>

 </table> 
</form>

    
</body>
</html>




















