<?Php

include("dba.php");
$result=mysqli_query($conn,"SELECT* from authors ORDER by id DESC");
error_reporting(0);

?>




<html>
<head>


</head>

<body >


<form action="function.php" method="POST">
  

   	 Author<input type="text" name="authors"  required> <br>
   	 Publisher <input type="text" name="public"  required> <br>
   	 <input type="submit" name="submit">
 
  
</form>

<table border="2">
    <tr>
        <th>Author</th>
        <th>Publisher</th>
    </tr>   
    
<?php
while($res=mysqli_fetch_array($result)){

  echo '<tr>';
  echo '<td>'.$res['authors'].'</td>';
  echo '<td>'.$res['public'].'</td>';  
 

  echo '<tr>';
}



?>


</table>




    
</body>
</html>

