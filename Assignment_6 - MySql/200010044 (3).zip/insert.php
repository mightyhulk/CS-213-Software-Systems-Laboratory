<?php
include("dba.php");

//print_r($_POST);

$author = $_POST['author'];
$public = $_POST['public'];

echo $author;
echo '<br>';
echo $public;

$sql = "INSERT INTO `authors`(`author`, `publisher`) VALUES ('$author','$public')";

$insert = mysqli_query($conn,$sql);

if($insert){

	echo "data insterted sucessfully";
}
else{

	echo "false";
}


?>