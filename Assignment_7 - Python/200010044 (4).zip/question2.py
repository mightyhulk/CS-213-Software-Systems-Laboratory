

class Person:
  def __init__(self, Age, Gender, State,Phone_number, Height, Weight):
    self.age = Age
    self.gender = Gender
    self.state =  State
    self.phone_number = Phone_number
    self.height = Height
    self.weight = Weight


p1 = Person(36, "Male", "Bihar", 7890567456, 110, 60)

print(p1.age)
print(p1.gender)
print(p1.state)
print(p1.phone_number)
print(p1.height)
print(p1.weight)
