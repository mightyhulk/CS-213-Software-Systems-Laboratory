from random import randint
from random import randint
from random import choice



nums = open("dataset.txt", "w")
list = ["male", "female"]
lists = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Jharkhand", "Kerala", "Madhya Pradesh","Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh","Uttarakhand","West Bengal"]


for i in range(10000):
  nums.write(str( randint(1,101)) + "," + choice(list) + "," + choice(lists)  + "," + str(randint(6000000000,9999999999)) + "," + str(randint(100,221)) + "," + str(randint(1,141)) +"\n" )


nums.close()
