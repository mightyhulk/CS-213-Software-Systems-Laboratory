from random import randint



x = open("dataset.txt", "r")


for i in range(10000):


  class Person:
    def __init__(self, Age, Gender, State, Phone_number, Height, Weight):
      self.age = Age
      self.gender = Gender
      self.state = State
      self.phone_number = Phone_number
      self.height = Height
      self.weight = Weight


  pi = Person()

  print(pi.age,pi.gender,pi.state,pi.phone_number,pi.height,pi.weight)


x.close()
